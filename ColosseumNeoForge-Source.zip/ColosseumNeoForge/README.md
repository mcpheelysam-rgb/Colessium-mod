# Colosseum Structure — NeoForge 1.21.4

This project packages the supplied `colosseum.nbt` as a Minecraft Java structure and adds a `/colosseum` command.

## Structure details

- Minecraft: Java Edition 1.21.4
- Mod loader: NeoForge 21.4.161
- Java toolchain: 21
- Structure size: 131 × 36 × 107 blocks
- Saved block entries: 127,635
- Structure resource: `src/main/resources/data/colosseum/structure/colosseum.nbt`

## In game

1. Install Minecraft Java 1.21.4 with NeoForge 21.4.x.
2. Install the built `colosseum-1.0.0.jar` into the instance's `mods` folder.
3. Enter a world with cheats enabled (or be an operator on a server).
4. Run `/colosseum`.

The command places the structure centred approximately eight blocks in front of the player, at the player's current feet-level Y coordinate. Choose a large, mostly clear area. It places more than 127,000 block entries and can cause a brief server/client pause. Make a world backup first.

## Build (including on a Chromebook without Linux)

This download is the complete **source project**, not a precompiled mod JAR. The project includes a GitHub Actions workflow at `.github/workflows/build.yml` that can compile the mod on GitHub's cloud runner, so you do not need Linux on the Chromebook.

1. Create a new GitHub repository in your browser.
2. Upload the contents of this project folder to the repository (keep the `.github` folder).
3. Open the repository's **Actions** tab and select **Build Colosseum mod**.
4. Run the workflow. When it finishes successfully, open the run and download the `colosseum-neoforge-1.21.4` artifact. It contains `colosseum-1.0.0.jar`.

The cloud build uses Java 21 and Gradle 9.2.1, and downloads NeoForge/Minecraft dependencies during the build. You can also build locally with Java 21 and Gradle by running `gradle build`.

NeoForge's official 1.21.4 setup requirements are documented at https://docs.neoforged.net/docs/1.21.4/gettingstarted/ .

## Notes

- The supplied NBT file is included unchanged.
- The structure contains standard vanilla blocks only (sand, stone bricks, sandstone variants, lanterns, slabs and stairs).
- The structure contains no saved entities.
- The command currently places the structure without rotating it and does not clear the destination area first.
