package com.sir.colosseum;

import com.mojang.brigadier.Command;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.Optional;

@Mod(ColosseumMod.MOD_ID)
public final class ColosseumMod {
    public static final String MOD_ID = "colosseum";
    private static final ResourceLocation COLOSSEUM_ID = ResourceLocation.fromNamespaceAndPath(MOD_ID, "colosseum");

    public ColosseumMod() {
    }

    @EventBusSubscriber(modid = MOD_ID)
    public static final class CommandsHandler {
        private CommandsHandler() {
        }

        @SubscribeEvent
        public static void registerCommands(RegisterCommandsEvent event) {
            event.getDispatcher().register(
                Commands.literal("colosseum")
                    .executes(context -> placeColosseum(context.getSource().getPlayerOrException()))
            );
        }
    }

    private static int placeColosseum(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Optional<StructureTemplate> structureOptional = level.getStructureManager().get(COLOSSEUM_ID);

        if (structureOptional.isEmpty()) {
            player.sendSystemMessage(Component.literal("Colosseum structure file could not be found."));
            return 0;
        }

        // Place the centre of the 131 x 107 structure about eight blocks in front of the player.
        // The NBT's origin is its minimum X/Y/Z corner.
        BlockPos centre = player.blockPosition().relative(player.getDirection(), 8);
        BlockPos origin = centre.offset(-65, 0, -53);

        StructureTemplate structure = structureOptional.get();
        StructurePlaceSettings settings = new StructurePlaceSettings()
            .setRotation(Rotation.NONE)
            .setIgnoreEntities(false);

        boolean placed = structure.placeInWorld(level, origin, origin, settings, level.getRandom(), 2);
        if (placed) {
            player.sendSystemMessage(Component.literal("Colosseum placed! Size: 131 x 36 x 107 blocks."));
            return Command.SINGLE_SUCCESS;
        }

        player.sendSystemMessage(Component.literal("The Colosseum could not be placed here. Try another location."));
        return 0;
    }
}
